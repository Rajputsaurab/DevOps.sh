[1]   https://thenewstack.io/new-kubernetes-ebook-learn-the-latest-in-kubernetes-deployments-and-trends/


[2]   https://servicemesh.es/


[3]   https://www.synerzip.com/wp-content/uploads/2020/04/Service-Mesh-Comparisons-Webinar-Synerzip.pdf


[4]   https://konghq.com/blog/multi-cluster-multi-cloud-service-meshes-with-cncfs-kuma-and-envoy/


[5]   https://docs.aws.amazon.com/app-mesh/index.html


[6]   https://www.cncf.io/wp-content/uploads/2020/08/rfma-servicemesh-cncf.pdf


[7]   https://thenewstack.io/an-exploratory-guide-to-the-service-mesh-platforms/


[8]   https://www.idc.com/getdoc.jsp?containerId=prUS47222420


[9]   https://buoyant.io/linkerd/


[10]   https://www.consul.io/docs/intro


[11]   https://learn.hashicorp.com/tutorials/consul/kubernetes-reference-architecture?in=consul/kubernetes


[12]   https://www.consul.io/docs/intro


[13]   https://istio.io/latest/docs/concepts/what-is-istio/


[14]   https://istio.io/latest/docs/concepts/what-is-istio/


[15]   https://thenewstack.io/new-kubernetes-ebook-learn-the-latest-in-kubernetes-deployments-and-trends/


[16]   https://thenewstack.io/new-kubernetes-ebook-learn-the-latest-in-kubernetes-deployments-and-trends/


[17]   https://thenewstack.io/new-kubernetes-ebook-learn-the-latest-in-kubernetes-deployments-and-trends/


[18]   https://containerjournal.com/topics/container-management/service-mesh-not-100-ready-for-wide-adoption/


[19]   https://enterprisersproject.com/article/2019/7/service-mesh-how-to-make-case


[20]   https://www.brillio.com/insights/service-mesh-why-it-matters-for-distributed-computing/


[21]   https://buoyant.io/2020/10/12/what-is-a-service-mesh/


[22]   https://itnext.io/service-mesh-for-the-developer-workflow-a-series-be7f91ee145e


[23]    https://www.vmware.com/content/dam/learn/en/amer/fy21/pdf/498818_Service_Mesh_for_Dummies.pdf


[24] https://www.ciscolive.com/c/dam/r/ciscolive/emea/docs/2020/pdf/DEVNET-1697.pdf


[25] https://istio.io/latest/docs/concepts/what-is-istio/


[26] https://buoyant.io/2020/10/12/what-is-a-service-mesh/

